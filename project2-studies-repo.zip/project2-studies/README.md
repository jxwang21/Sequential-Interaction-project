# Project 2 — Interaction Studies

Four standalone interaction studies exported from published Claude artifacts. Each is a single self-contained `index.html` with its own `STUDY.md`. They share one dark, outlined, bevelled-tile visual language and a common "solve a small puzzle, then something opens or starts" pattern, which makes them good building blocks for a connected sequential prototype.

## The studies

| # | Folder | What happens |
|---|---|---|
| 1 | [`studies/01-select-the-frames`](studies/01-select-the-frames/STUDY.md) | A clock reads 3:17. Press three frames in the order 3 → 1 → 7 (triangles, eye, dots) and the clock's glass cover swings open, revealing a key. |
| 2 | [`studies/02-rotate-the-city`](studies/02-rotate-the-city/STUDY.md) | Follow the four-arrow route (up, right, down, left) on a direction pad. The city rotates 15 degrees per correct step; after four, a door opens and shows "MOON". |
| 3 | [`studies/03-place-the-letters`](studies/03-place-the-letters/STUDY.md) | Floating tiles N, O, O, M are placed into slots to spell the mirrored reflection clue "MOON". A correct word makes a spinning top rise and hold still. |
| 4 | [`studies/04-activate-the-spinning-top`](studies/04-activate-the-spinning-top/STUDY.md) | A clock reads 3:17 above a still top. Press marks 3 → 1 → 7 and the top starts spinning. |

## Run them

No build step and no installed dependencies. Requirements: a modern browser. Node 18+ or Python 3 is optional, only to serve the files.

```bash
# open one study directly
open studies/01-select-the-frames/index.html

# or serve the whole repo and browse all four (http://localhost:3000)
npm start

# or with Python
python3 -m http.server 8000
```

Each study folder also has a `package.json` with the same `npm start` script (it uses `npx serve`; nothing is added to the project).

**Network note:** Study 2 loads the Jost font (weight 300) from Google Fonts for the "MOON" text. Offline it falls back to Helvetica Neue / Arial. The other three studies need no network access.

## Layout

```
project2-studies/
├── README.md
├── package.json
├── .gitignore
└── studies/
    ├── 01-select-the-frames/          index.html  STUDY.md  package.json
    ├── 02-rotate-the-city/            index.html  STUDY.md  package.json
    ├── 03-place-the-letters/          index.html  STUDY.md  package.json
    └── 04-activate-the-spinning-top/  index.html  STUDY.md  package.json
```

The `index.html` files are byte-for-byte the published artifact pages. Their first `<style>` block and viewport meta are the artifact host's boilerplate; they were kept so nothing about the studies' appearance or behaviour changed.

## How they can support a connected sequential prototype

**Shared story threads already in the studies**

- The clock reading **3:17** appears in studies 1 and 4, and the code **3 → 1 → 7** is the answer in both.
- The word **MOON** is revealed in study 2 (inside the door) and is the answer in study 3.
- The **spinning top** is the reward in study 3 (rises, still) and the subject of study 4 (starts spinning).

**Shared interaction pattern.** All four use the same structure: press with a pointer or Enter/Space, a `.down` pressed state that cancels if the pointer leaves, a check on release, a lock while animating, a wrong-answer wipe, a solved end state, and a round reset button. A connected prototype can treat each study as a scene with the same contract: `start`, `solved`, `reset`.

**Shared design tokens.** The same palette (`#121212` ground, `#1d1d1d` panels, `#9a9a9a` / `#5e5e5e` strokes, `#dcdcdc` highlights), 1.5 px non-scaling strokes, bevelled tiles and a 44 px round reset button appear in all four. Study 4 names its CSS variables differently (`--ink`, `--fill` instead of `--lit`, `--panel`) but uses the same values.

**Things to handle when combining them in one page**

- **ID collisions:** `#stage` (studies 1–3), `#reset` (all), `#top` and `#scene` (studies 3 and 4), plus `<filter>` ids, repeat across files.
- **Global CSS:** each file styles `body`, `:root`, a bare `svg` rule (studies 1–3), `.reset`, and has its own `--u` or `--s` sizing unit. Combining them needs namespacing, shadow DOM, or one iframe per scene.
- **Script scope:** each script is wrapped in an IIFE and exposes nothing, so a connected version needs a small hook in each (for example a "solved" callback and a reset method).
- **Motion approach differs:** studies 1, 2 and 4's press states use CSS transitions; study 2's rotation drives a CSS variable; study 3 animates tiles and the top with `requestAnimationFrame`; study 4 spins its top with `requestAnimationFrame`.
- **Accessibility:** studies 1–3 honour `prefers-reduced-motion`; study 4 does not.

## Draft interaction sequence (not yet built, pending confirmation)

1. **Study 1** — solve the frames; the clock opens and shows a key.
2. **Study 2** — solve the route; the door opens and shows MOON.
3. **Study 3** — spell MOON; the top rises.
4. **Study 4** — enter 3 → 1 → 7; the top spins.

Open questions are listed in the hand-off message; the sequence and transition style should be confirmed before building.
